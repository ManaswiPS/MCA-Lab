#include <lpc214x.h>
void delay(int);
int i;
//unsigned int a[]={0x01,0x04,0x10,0x40,0x02,0x08,0x20,0x80};
unsigned int a[]={0x055,0xAA};
void main(){
	IO0DIR=0xFFFFFFFF;
	while(1)
	{
		for(int i=0;i<2;i++)
		{
			IO0SET|=a[i];
			delay(500000);
			IO0CLR|=a[i];
		}
	}
}

void delay(int k)
{
for(int j=0;j<k;j++);
}