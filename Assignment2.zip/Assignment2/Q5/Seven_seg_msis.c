#include<lpc21xx.h>

void delay(unsigned int a)   //Delay Function
{
    for(a=1;a<=75000;a++);
}

int main()
{
   IO0DIR|=0xFFFFFFFF;  // Port 0 is configured as output
	 IO1DIR|=0xFFFFFFFF;
while(1)
 { 
	 
	    IO0SET|=0x00B0EDF9;
	    IO1SET|=0xDB000000;//Sets corresponding pins HIGH
      delay(75000);  // Calls delay function
		  IO0CLR|=0xFFFFFFFF;  //Sets corresponding pins LOW
	  
  }
 return 0;
}