#include <lpc214x.h>

void delay(int);
void main()
{
	IO0DIR=0xFFFFFF0F;
	while(1)
	{
		if((IO0PIN & (1<<4))==0)
		{	IO0SET|=0x0F;
			delay(100000);
			IO0CLR|=0x0F;
			delay(100000);
		}
		else
			IO0CLR|=0x0F;
	}
	return 0;
}

void delay(int k)
{
for (int j=0;j<k;j++);
}	

	